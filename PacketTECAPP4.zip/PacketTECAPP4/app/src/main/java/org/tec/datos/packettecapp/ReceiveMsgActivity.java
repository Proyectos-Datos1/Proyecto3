package org.tec.datos.packettecapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ReceiveMsgActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_msg);
    }
}
